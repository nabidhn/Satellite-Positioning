
PR = load('PR.txt');       
SVPOS = load('SVPOS.txt');   

x = [0; 0; 0; 0];


c = 299792458; 
threshold = 1;
delta = Inf;  
while delta > threshold
  
    d = sqrt(sum((SVPOS - x(1:3)').^2, 2));
    
   
    residuals = PR - (d + x(4));
    
  
    H = [-((SVPOS(:,1) - x(1)) ./ d), ...
         -((SVPOS(:,2) - x(2)) ./ d), ...
         -((SVPOS(:,3) - x(3)) ./ d), ...
         ones(size(d))];
     
  
    delta_x = (H' * H) \ H' * residuals;
    x = x + delta_x; 
    

    delta = norm(delta_x(1:3));
end


fprintf('User position (x, y, z): %.3f, %.3f, %.3f\n', x(1), x(2), x(3));
fprintf('Clock bias: %.3f meters\n', x(4));


iterations 
Upos

xyz2llh(Upos(1:3))
norm(Upos(1:3))